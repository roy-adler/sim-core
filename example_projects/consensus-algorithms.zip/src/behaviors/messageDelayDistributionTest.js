/**
 * @param {AgentState} state of the agent
 * @param {AgentContext} context of the agent
 */
const behavior = (state, context) => {
  state.addMessage("hash", "stop", {
      status: "success", reason: "TEST ok"
    });
};
